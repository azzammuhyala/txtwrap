__version__ = '3.0.0'
__author__ = 'azzammuhyala'
__license__ = 'MIT'