# TxTWrap 🔤
A tool for wrapping a text.🔨

> **⚠️All documents are in the each module.⚠️**

All constants and functions❕:
- `LOREM_IPSUM_W`
- `LOREM_IPSUM_S`
- `LOREM_IPSUM_P`
- `mono`
- `word`
- `wrap`
- `align`
- `shorten`

Mod `python -m txtwrap` Commands❗:
```shell
python -m txtwrap --help
```